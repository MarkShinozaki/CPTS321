using System;
using System.ComponentModel;
using System.Diagnostics;

namespace GarbageCollectionDemo
{
    class StaticVariableDemo : IDisposable
    {
        static int staticCounter = 0;
        int instanceCounter = 0;
        long memoryInCache = 0;

        public StaticVariableDemo()
        {
            staticCounter++;
            instanceCounter++;
        }

        public void Dispose()
        {
            staticCounter--;
            instanceCounter--;

            if (staticCounter < 0) staticCounter = 0;
            if (instanceCounter < 0) instanceCounter = 0;

            long memoryUsed = GC.GetTotalMemory(false);
            memoryInCache += memoryUsed;
            Console.WriteLine("Memory stored in cache: " + memoryInCache / 1024 + " KB");
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            // Create an instance of the PerformanceCounter class to monitor memory usage.
            var memProcess = Process.GetCurrentProcess();
            var procName = memProcess.ProcessName;
            var memCounter = new PerformanceCounter("Process", "Private Bytes", memProcess.ProcessName);

            // Create an instance of the GarbageCollector class to monitor GC performance.
            var gcCounter = new PerformanceCounter(".NET CLR Memory", "# Gen 0 Collections", procName);
            var gcTimeCounter = new PerformanceCounter(".NET CLR Memory", "% Time in GC", procName);

            Console.WriteLine("Starting memory usage: " + memCounter.NextValue() / 1024 + " KB");

            // Create some instances of the StaticVariableDemo class to generate garbage.
            for (int i = 0; i < 20000; i++)
            {
                using (StaticVariableDemo obj = new StaticVariableDemo())
                {
                    // Do nothing with the object
                }
            }

            // Force garbage collection and wait for it to complete.
            GC.Collect();
            GC.WaitForPendingFinalizers();

            Console.WriteLine("Memory usage after generating garbage: " + memCounter.NextValue() / 1024 + " KB");

            // Get and display GC performance data.
            int numCollections = (int)gcCounter.NextValue();
            float timeInGc = gcTimeCounter.NextValue();
            string timeInGcTwoDecim = timeInGc.ToString("F2");
            Console.WriteLine("Number of GC collections: " + numCollections);
            Console.WriteLine("Percentage of time spent in GC: " + timeInGcTwoDecim + "%");
        }
    }
}
