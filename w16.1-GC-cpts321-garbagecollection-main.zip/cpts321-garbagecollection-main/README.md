# Garbage Collection Demo
Aayush Bajoria, Gunnar Jackson, Toufic Majdalani
